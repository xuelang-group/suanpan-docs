package com.xuelang.spos.mq.dto;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

@Data
public class MqEventDto {
    public static final String EMPTY_EVENT = "empty_event";

    private String event = EMPTY_EVENT;

    private String from;

    private JSONObject data;
}
