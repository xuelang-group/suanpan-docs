package com.xuelang.spos.store.exception;

public class DownloadDockerException extends Exception {
    public DownloadDockerException() {
    }

    public DownloadDockerException(String message) {
        super(message);
    }

    public DownloadDockerException(String message, Throwable cause) {
        super(message, cause);
    }
}
