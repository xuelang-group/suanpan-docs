package com.xuelang.spos.oss.exception;

public class AddToAliyunOssException extends Exception {
    public AddToAliyunOssException() {
    }

    public AddToAliyunOssException(String message) {
        super(message);
    }

    public AddToAliyunOssException(String message, Throwable cause) {
        super(message, cause);
    }
}
