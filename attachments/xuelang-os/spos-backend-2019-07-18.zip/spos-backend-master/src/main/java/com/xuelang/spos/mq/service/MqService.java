package com.xuelang.spos.mq.service;

import com.alibaba.fastjson.JSONObject;

import java.util.List;

public interface MqService {
    void sendSuccessMessageToTarget(String target, JSONObject output);
    void sendSuccessMessageToTarget(List<String> targets, JSONObject output);
    void sendErrorMessageToTarget(List<String> targets, String errorMessage);
}
