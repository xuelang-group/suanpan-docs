package com.xuelang.spos.mq.constant;

import java.util.Arrays;
import java.util.List;

public class InputAppList {
    public static final List<String> apps = Arrays.asList("in1", "in2");
}
