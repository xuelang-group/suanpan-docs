package com.xuelang.spos.mq.handler;

import com.xuelang.spos.mq.response.XReadGroupResponse;

public interface XReadGroupHandler {
    void handle(XReadGroupResponse response);
}
