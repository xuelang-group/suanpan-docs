package com.xuelang.spos.config;


import lombok.Getter;
import org.springframework.stereotype.Component;

import java.util.Base64;
import java.util.Map;

@Component
public class InitAppList {
    @Getter
    private String content;

    public void buildByOptions(Map<String, String> options) {
        String base64Content = options.get("app-data");
        byte[] bytes = Base64.getDecoder().decode(base64Content);
        this.content = new String(bytes);
    }
}
