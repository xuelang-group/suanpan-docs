package com.xuelang.spos.mq;

import com.xuelang.spos.mq.handler.ExceptionHandler;
import com.xuelang.spos.mq.handler.XReadGroupHandler;
import com.xuelang.spos.mq.options.Consumer;
import com.xuelang.spos.mq.options.Message;
import com.xuelang.spos.mq.options.Queue;

public interface MqClient {
    void createQueue(Queue queue, boolean existedOk);
    String sendMessage(Message message);
    void subscribeQueue(Consumer consumer, XReadGroupHandler handler, ExceptionHandler exceptionHandler);
    void ackMessage(String queue, String group, String... messageIds);
    void destroy();
}
