package com.xuelang.spos.mq;

public class MqEventType {
    public static final String QUERY_APP = "queryApps";
    public static final String DOWNLOAD_APP = "downloadApp";
    public static final String QUERY_DOWNLOAD_PROGRESS = "queryDownloadProgress";
    public static final String DEPLOY_APP = "deployApp";
    public static final String QUERY_DEPLOY_PROGRESS = "queryDeployProgress";
    public static final String UNINSTALL_APP = "uninstallApp";
}
