package com.xuelang.spos.oss.service;

import com.xuelang.spos.oss.bo.AppBo;
import com.xuelang.spos.oss.constant.AppStatus;

import java.util.List;

public interface AppInformationService {
    void sync(boolean force, String content);
    List<AppBo> queryAll();

    void updateAppStatus(String spid, AppStatus status);
}
