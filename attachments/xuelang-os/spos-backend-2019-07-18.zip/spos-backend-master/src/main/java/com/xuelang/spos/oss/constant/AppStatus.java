package com.xuelang.spos.oss.constant;

public enum  AppStatus {
    BUILT_IN("builtIn"),
    CAN_INSTALL("canInstall"),
    DOWNLOADING("downloading"),
    INSTALLED("installed");

    private String status;

    AppStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}