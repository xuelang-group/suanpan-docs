package com.xuelang.spos.store.service;

import com.xuelang.spos.store.vo.ActionVo;
import com.xuelang.spos.store.exception.DeployDockerException;
import com.xuelang.spos.store.exception.DownloadDockerException;

public interface AppActionService {
    ActionVo download(String id);
    ActionVo downloadProgress(String id) throws DownloadDockerException;

    ActionVo deploy(String id);
    ActionVo deployStatus(String id) throws DeployDockerException;

    ActionVo uninstall(String id);
}
