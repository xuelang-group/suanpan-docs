package com.xuelang.spos.store.vo;

import lombok.Data;

@Data
public class ActionVo {
    private String id;
    private String status;
    private String downloadId;
    private Integer progress;
    private String deployStatus;
}
