package com.xuelang.spos.mq.bussiness;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.xuelang.spos.config.StreamOption;
import com.xuelang.spos.mq.MqClient;
import com.xuelang.spos.mq.MqEventType;
import com.xuelang.spos.mq.dto.MqEventDto;
import com.xuelang.spos.mq.handler.XReadGroupHandler;
import com.xuelang.spos.mq.options.Message;
import com.xuelang.spos.mq.response.XReadGroupResponse;
import com.xuelang.spos.oss.service.AliyunStoreUserAppService;
import com.xuelang.spos.store.service.OsStoreService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class MessageRecvHandler implements XReadGroupHandler {

    @Autowired
    private StreamOption streamOption;
    @Autowired
    private AliyunStoreUserAppService aliyunStoreUserAppService;
    @Autowired
    private OsStoreService osStoreService;

    private MqEventDto extractOutOneInput(XReadGroupResponse response) {
        MqEventDto eventDto = new MqEventDto();
        List<Map<String, String>> data = response.getData();
        for (Map<String, String> item: data) {
            if (item.containsKey("in1")) {
                String value = item.get("in1");
                JSONObject parseObject = JSON.parseObject(value);
                String event = parseObject.getString("event");
                JSONObject eventData = parseObject.getJSONObject("data");
                eventDto.setEvent(event);
                eventDto.setData(eventData);
                return eventDto;
            }
        }
        return eventDto;
    }

    private void sendSuccessMessage(MqClient mqClient, String key, String data) {
        JSONObject dataObject = new JSONObject();
        dataObject.put(key, data);

        JSONObject debugObject = new JSONObject();
        Map<String, Boolean> debugMap = new HashMap<>();
        debugMap.put("debug", true);
        debugObject.put("global", debugMap);
        Message message = Message.builder()
                .queue(streamOption.getSendQueue())
                .keysAndValues(Message.prepareKeysAndValues(
                        "node_id",
                        streamOption.getNodeId(),
                        "success", "true",
                        "out1", dataObject.toJSONString(),
                        "extra", debugObject.toJSONString()
                ))
                .build();
        mqClient.sendMessage(message);
        log.info("send success message to {}: {}", streamOption.getSendQueue(), dataObject);
    }

    private void sendErrorMessage(MqClient mqClient, String eventName) {
        Message message = Message.builder()
                .queue(streamOption.getSendQueue())
                .keysAndValues(Message.prepareKeysAndValues(
                        "node_id",
                        streamOption.getNodeId(),
                        "success", "false",
                        "msg", "exception threw for " + eventName)
                )
                .build();
        mqClient.sendMessage(message);
    }

    private void dispatchEvent(MqEventDto eventDto) {
        MqClient mqClient = streamOption.buildRedisClient();
        try {
            switch (eventDto.getEvent()) {
                case MqEventType.QUERY_INSTALLED_APP:
                    String installedApp = aliyunStoreUserAppService.fetchInstalledAppContent();
                    sendSuccessMessage(mqClient, eventDto.getEvent(), installedApp);
                    break;
                case MqEventType.QUERY_ALL_APP:
                    String allApp = aliyunStoreUserAppService.fetchAllAppContent();
                    sendSuccessMessage(mqClient, eventDto.getEvent(), allApp);
                    break;
                case MqEventType.QUERY_TO_INSTALL_APP:
                    String toInstallApp = aliyunStoreUserAppService.fetchToInstallAppContent();
                    sendSuccessMessage(mqClient, eventDto.getEvent(), toInstallApp);
                    break;
                case MqEventType.DOWNLOAD_APP:
                    JSONObject data = eventDto.getData();
                    String id = data.getString("id");
                    String downloadId = osStoreService.download(id);
                    sendSuccessMessage(mqClient, eventDto.getEvent(), downloadId);
                    break;
            }
        } catch (Exception e) {
            log.error("dispatchEvent {} failed", eventDto.getEvent());
            sendErrorMessage(mqClient, eventDto.getEvent());
        } finally {
            mqClient.destroy();
        }
    }

    @Override
    public void handle(XReadGroupResponse response) {
        log.info("receive: {}", response);
        MqEventDto eventDto = extractOutOneInput(response);
        if (eventDto.getEvent().equals(MqEventDto.EMPTY_EVENT)) {
            return;
        }
        dispatchEvent(eventDto);
    }
}
