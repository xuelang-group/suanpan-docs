package com.xuelang.spos.store.dto;

import lombok.Data;

@Data
public class ProgressDto {
    /**
     * 下载进度
     */
    private int progress;
    /**
     * 是否正在下载
     */
    private boolean running;
    /**
     * 部署状态
     */
    private String status;
}
