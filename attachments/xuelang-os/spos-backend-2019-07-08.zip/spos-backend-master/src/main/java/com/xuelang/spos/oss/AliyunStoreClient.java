package com.xuelang.spos.oss;

import com.aliyun.oss.OSSClient;
import com.aliyun.oss.model.OSSObject;
import com.aliyun.oss.model.OSSObjectSummary;
import com.aliyun.oss.model.ObjectListing;
import io.micrometer.core.instrument.util.IOUtils;

import java.io.*;

public class AliyunStoreClient {

    private OSSClient ossClient;

    public AliyunStoreClient(String getEndpoint, String getAccessKeyId, String getAccessKeySecret) {
        this.ossClient = new OSSClient(
                getEndpoint,
                getAccessKeyId,
                getAccessKeySecret
        );
    }

    public void putContentToBucket(String bucketName, String key, String content) {
        this.ossClient.putObject(bucketName, key, new ByteArrayInputStream(content.getBytes()));
    }

    public void putContentToBucket(String bucketName, String key, File file) {
        this.ossClient.putObject(bucketName, key, file);
    }

    public String getContent(String bucketName, String key) {
        OSSObject ossObject = this.ossClient.getObject(bucketName, key);
        try {
            InputStream inputStream = ossObject.getObjectContent();
            String content = IOUtils.toString(inputStream);
            ossObject.close();
            return content;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public byte[] getByte(String bucketName, String key) {
        OSSObject ossObject = this.ossClient.getObject(bucketName, key);
        try {
            InputStream inputStream = ossObject.getObjectContent();
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024 * 4];
            int n = 0;
            while (-1 != (n = inputStream.read(buffer))) {
                output.write(buffer, 0, n);
            }
            ossObject.close();
            return output.toByteArray();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean checkObjectExistForBucket(String bucketName, String key) {
        ObjectListing objectListing = ossClient.listObjects(bucketName);
        for (OSSObjectSummary objectSummary : objectListing.getObjectSummaries()) {
            if (objectSummary.getKey().equals(key)) {
                return true;
            }
        }
        return false;
    }

    public void destroy() {
        this.ossClient.shutdown();
    }
}
