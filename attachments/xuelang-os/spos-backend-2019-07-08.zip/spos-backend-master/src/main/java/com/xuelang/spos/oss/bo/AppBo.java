package com.xuelang.spos.oss.bo;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Data
public class AppBo {
    private Long id;
    private String name;
    private String version;
    private String description;
    private List<String> icons = new ArrayList<>();
    private String type;
    private String spid;
    private Map splashScreen;
    private String homeUrl;
    private String widgetUrl;
    private List<String> permissions = new ArrayList<>();
}
