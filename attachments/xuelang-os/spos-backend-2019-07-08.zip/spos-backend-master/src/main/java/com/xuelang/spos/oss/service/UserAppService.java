package com.xuelang.spos.oss.service;

public interface UserAppService {
    void syncInitialAppInformation();
    String fetchAllAppContent();
    String fetchInstalledAppContent();
    String fetchToInstallAppContent();
}
