package com.xuelang.spos.store.exception;

public class DeployDockerException extends Exception {
    public DeployDockerException() {
    }

    public DeployDockerException(String message) {
        super(message);
    }

    public DeployDockerException(String message, Throwable cause) {
        super(message, cause);
    }
}
