package com.xuelang.spos;

import com.xuelang.spos.common.AppUtils;
import com.xuelang.spos.config.AliyunStoreOption;
import com.xuelang.spos.config.StreamOption;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
@Slf4j
public class SposApplication implements ApplicationRunner {
	@Autowired
	private StreamOption streamOption;
	@Autowired
	private AliyunStoreOption aliyunStoreOption;

	private static Map<String, String> parseArguments(String[] args) {
		Map<String, String> options = new HashMap<>();
		for (int i = 0; i < args.length - 1; i += 2) {
			String key = args[i].replace("--", "");
			String value = AppUtils.trimQuoteIfExist(args[i+1]);
			options.put(key, value);
		}
		return options;
	}

	public static void main(String[] args) {
		SpringApplication.run(SposApplication.class, args);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		Map<String, String> options = parseArguments(args.getSourceArgs());
		streamOption.buildByOptions(options);
		aliyunStoreOption.buildByOptions(options);
	}
}
