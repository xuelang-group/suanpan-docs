package com.xuelang.spos.oss.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.xuelang.spos.config.AliyunStoreOption;
import com.xuelang.spos.oss.AliyunStoreClient;
import com.xuelang.spos.oss.bo.AppBo;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;


import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.util.ResourceUtils.getFile;

@Service
public class AliyunStoreUserAppService implements UserAppService {
    private final String ALL = "test_all_app";
    private final String INSTALLED = "test_installed_app";

    @Autowired
    private AliyunStoreOption storeOption;

    private String getResource(String resourceName) {
        try {
            InputStream inputStream = this.getClass().getResourceAsStream("/app/" + resourceName);
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void syncInitialAppInformation() {
        AliyunStoreClient storeClient = storeOption.buildClient();
        boolean hasAll = storeClient.checkObjectExistForBucket(storeOption.getBucketName(), ALL);
        if (!hasAll) {
            String allApp = getResource("allApp.json");
            storeClient.putContentToBucket(storeOption.getBucketName(), ALL, allApp);
        }
        boolean hasInstalled = storeClient.checkObjectExistForBucket(storeOption.getBucketName(), INSTALLED);
        if (!hasInstalled) {
            String installApp = getResource("homeApp.json");
            storeClient.putContentToBucket(storeOption.getBucketName(), INSTALLED, installApp);
        }
        storeClient.destroy();
    }

    @Override
    public String fetchAllAppContent() {
        AliyunStoreClient storeClient = storeOption.buildClient();
        String content = storeClient.getContent(storeOption.getBucketName(), ALL);
        storeClient.destroy();
        return content;
    }

    @Override
    public String fetchInstalledAppContent() {
        AliyunStoreClient storeClient = storeOption.buildClient();
        String content = storeClient.getContent(storeOption.getBucketName(), INSTALLED);
        storeClient.destroy();
        return content;
    }

    @Override
    public String fetchToInstallAppContent() {
        String allContent = fetchAllAppContent();
        List<AppBo> allApps = parseAppContent(allContent);
        String installedContent = fetchInstalledAppContent();
        List<AppBo> installedApps = parseAppContent(installedContent);

        List<Long> installAppIds = installedApps.stream()
                .map(AppBo::getId)
                .collect(Collectors.toList());
        List<AppBo> toInstallApps = allApps.stream().filter(app -> !installAppIds.contains(app.getId()))
                .collect(Collectors.toList());

        return JSON.toJSONString(toInstallApps);
    }

    private List<AppBo> parseAppContent(String allContent) {
        return JSON.parseObject(allContent, new TypeReference<List<AppBo>>() {});
    }
}
