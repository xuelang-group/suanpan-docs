package com.xuelang.spos.mq.service;

import com.xuelang.spos.config.StreamOption;
import com.xuelang.spos.mq.MqClient;
import com.xuelang.spos.mq.options.Message;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class RedisMqService implements MqService {

    @Autowired
    private StreamOption streamOption;

    @Override
    public void send(String key, String content) {
        MqClient client = streamOption.buildRedisClient();
        Message message = Message.builder()
                .queue(streamOption.getSendQueue())
                .keysAndValues(Message.prepareKeysAndValues(key, content))
                .build();
        client.sendMessage(message);
        log.info("message sent to {}: {}, content: {}", message.getQueue(), key, content);
        client.destroy();
    }
}
