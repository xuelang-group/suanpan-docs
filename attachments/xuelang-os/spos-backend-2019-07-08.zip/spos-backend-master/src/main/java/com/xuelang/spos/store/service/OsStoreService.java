package com.xuelang.spos.store.service;

import com.xuelang.spos.store.dto.ProgressDto;
import com.xuelang.spos.store.exception.DeployDockerException;
import com.xuelang.spos.store.exception.DownloadDockerException;

public interface OsStoreService {
    String download(String id);
    ProgressDto downloadProgress(String downloadId) throws DownloadDockerException;

    void deploy(String id);
    ProgressDto deployProgress(String id) throws DeployDockerException;
}
