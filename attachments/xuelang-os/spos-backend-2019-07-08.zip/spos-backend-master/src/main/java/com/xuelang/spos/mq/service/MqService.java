package com.xuelang.spos.mq.service;

public interface MqService {
    void send(String key, String content);
}
