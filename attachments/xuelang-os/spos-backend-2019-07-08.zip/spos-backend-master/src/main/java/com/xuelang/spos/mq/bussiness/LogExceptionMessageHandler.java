package com.xuelang.spos.mq.bussiness;

import com.xuelang.spos.mq.handler.ExceptionHandler;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LogExceptionMessageHandler implements ExceptionHandler {
    @Override
    public void handle(Exception e) {
      log.error(e.getMessage());
    }
}
