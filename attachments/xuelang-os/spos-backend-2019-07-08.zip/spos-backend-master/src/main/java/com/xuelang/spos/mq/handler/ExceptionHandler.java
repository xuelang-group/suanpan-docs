package com.xuelang.spos.mq.handler;

public interface ExceptionHandler {
    void handle(Exception e);
}
