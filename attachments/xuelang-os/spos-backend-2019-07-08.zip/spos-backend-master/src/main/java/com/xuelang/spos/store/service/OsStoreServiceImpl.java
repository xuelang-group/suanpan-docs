package com.xuelang.spos.store.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.xuelang.spos.common.AppUtils;
import com.xuelang.spos.config.AliyunStoreOption;
import com.xuelang.spos.config.GlobalEnv;
import com.xuelang.spos.oss.AliyunStoreClient;
import com.xuelang.spos.store.dto.ProgressDto;
import com.xuelang.spos.store.exception.DeployDockerException;
import com.xuelang.spos.store.exception.DownloadDockerException;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import java.io.*;
import java.util.*;

/**
 * @author: moyan.zk
 * @date:2019/6/26
 */
@Slf4j
@Service
public class OsStoreServiceImpl implements OsStoreService {

    @Autowired
    private AliyunStoreOption aliyunStoreOption;

    @Autowired
    private GlobalEnv globalEnv;

    private String urlHelper(String host, String path) {
        return String.format("http://%s/%s", host, path);
    }

    private String executeRequest(Request request) {
        OkHttpClient client = new OkHttpClient();
        try {
            Response response = client.newCall(request).execute();
            String content = response.body().string();
            log.info("execute url: {}, response: {}", request.url(), content);
            return content;
        } catch (IOException e) {
            log.error("executeRequest: {}", AppUtils.stackTraceAsString(e));
            throw new RuntimeException(e);
        } finally {
            client.connectionPool().evictAll();
        }
    }

    public String queryAppInfo(String id) {
        JSONObject json = new JSONObject();
        json.put("id", id);
        RequestBody body = RequestBody.create(
                MediaType.parse("application/json; charset=utf-8"), json.toJSONString()
        );
        Request request = new Request.Builder()
                .url(urlHelper(globalEnv.getSpHost(), "app/get"))
                .header("set-cookie", globalEnv.getSpSid())
                .post(body)
                .build();
        return executeRequest(request);
    }

    public String queryGraphFromOss(String appInfo) {
        JSONObject app = JSON.parseObject(appInfo);
        String ossKey = app.getJSONObject("appInfo").getString("data");
        AliyunStoreClient aliyunStoreClient = aliyunStoreOption.buildClient();
        byte[] bytes = aliyunStoreClient.getByte(aliyunStoreOption.getBucketName(), ossKey);
        // 转为无符号位整数
        int[] bufferNew = new int[bytes.length];
        for (int i = 0; i < bytes.length; i++) {
            int u = bytes[i] & 0xFF;
            bufferNew[i] = u;
        }
        // 解析
        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("nashorn");
        try {
            InputStream inputStream = this.getClass().getResourceAsStream("/script/uint8.js");
            engine.eval(new InputStreamReader(inputStream));
        } catch (Exception e) {
            log.error(AppUtils.stackTraceAsString(e));
            throw new RuntimeException(e);
        }
        Invocable invocable = (Invocable) engine;
        try {
            return invocable
                    .invokeFunction("decompressFromUint8Array", bufferNew)
                    .toString();
        } catch (Exception e) {
            log.error("decompressFromUint8Array fail: {}", AppUtils.stackTraceAsString(e));
            throw new RuntimeException(e);
        }
    }

    private String dockerRepoUrl(String repo) {
        return String.format("%s/%s", globalEnv.getSpDockerRegistryHost(), repo);
    }

    public List<String> extractDownloadRepoUrls(String fromOss) {
        List<String> urls = new ArrayList<>();
        JSONObject processes = JSON.parseObject(fromOss).getJSONObject("processes");
        if (processes.size() == 0)
            return urls;

        Map mapTypes = JSON.parseObject(processes.toJSONString());
        // 获取下载地址
        for (Object key : mapTypes.keySet()) {
            JSONObject jsonObject = (JSONObject) mapTypes.get(key);
            String dockerRepo = jsonObject
                    .getJSONObject("metadata")
                    .getJSONObject("def")
                    .getString("dockerRepo");
            if (StringUtils.isNotBlank(dockerRepo) &&
                    !urls.contains(dockerRepoUrl(dockerRepo))
            ) {
                urls.add(dockerRepoUrl(dockerRepo));
            }
        }
        return urls;
    }

    public String requestDownload(List<String> repoUrls) {
        RequestBody body = RequestBody.create(
                MediaType.parse("application/json; charset=utf-8"), JSON.toJSONString(repoUrls)
        );
        Request request = new Request.Builder()
                .url(urlHelper(globalEnv.getSpServiceDockerRegistryUrl(), "downloads"))
                .post(body)
                .build();
        String content = executeRequest(request);
        JSONObject jsonObject = JSON.parseObject(content);
        return jsonObject.getString("download_id");
    }

    @Override
    public String download(String id) {
        String appInfo = queryAppInfo(id);
        String fromOss = queryGraphFromOss(appInfo);
        List<String> repoUrls = extractDownloadRepoUrls(fromOss);
        String downloadId = requestDownload(repoUrls);
        log.info("download app: {}, downloadId: {}", id, downloadId);
        return downloadId;
    }

    @Override
    public ProgressDto downloadProgress(String downloadId) throws DownloadDockerException {
        ProgressDto progressDto = new ProgressDto();
        String path = "progresses/" + downloadId;
        Request request = new Request.Builder()
                .url(urlHelper(globalEnv.getSpServiceDockerRegistryUrl(), path))
                .build();
        String content = executeRequest(request);
        JSONObject allProgress = JSON.parseObject(content);
        int process = 0;
        for (String key : allProgress.keySet()) {
            String value = (String) allProgress.get(key);
            if (value.startsWith("E-")) {
                throw new DownloadDockerException(value);
            }
            process = process + Integer.parseInt(value.replace("%", ""));
        }
        process = process / allProgress.size();
        progressDto.setProgress(process);
        progressDto.setRunning(process != 100);
        return progressDto;
    }

    @Override
    public void deploy(String id) {
        JSONObject dataJson = new JSONObject();
        dataJson.put("id", id);
        RequestBody body = RequestBody.create(
                MediaType.parse("application/json; charset=utf-8"), dataJson.toJSONString()
        );
        Request request = new Request.Builder()
                .url(urlHelper(globalEnv.getSpHost(), "predict/deploy"))
                .header("set-cookie", globalEnv.getSpSid())
                .post(body)
                .build();
        executeRequest(request);
        log.info("deployed app: {}", id);
    }

    @Override
    public ProgressDto deployProgress(String id) throws DeployDockerException {
        JSONObject json = new JSONObject();
        json.put("id", id);
        RequestBody body = RequestBody.create(
                MediaType.parse("application/json; charset=utf-8"), json.toJSONString()
        );
        Request request = new Request.Builder()
                .url(urlHelper(globalEnv.getSpHost(), "predict/status"))
                .header("set-cookie", globalEnv.getSpSid())
                .post(body)
                .build();
        String content = executeRequest(request);
        String status = JSON.parseObject(content)
                .getJSONObject("map")
                .getString("status");
        if (StringUtils.isBlank(status)) {
            throw new DeployDockerException(id);
        }
        int progress = Integer.parseInt(status);
        ProgressDto progressDto = new ProgressDto();
        progressDto.setProgress(progress);
        return progressDto;
    }
}
